import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'commodity-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  public logoPath:string;
  
  constructor(public router:Router){
    this.logoPath="./assets/logo.png";
  }

  ngOnInit(){
    this.router.navigate(['']);
  }
}
