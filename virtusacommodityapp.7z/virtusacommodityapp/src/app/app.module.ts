import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { ServicesMenu } from './services/services.menu';
import { MenubarModule } from 'primeng/menubar';
import { ReporterComponent } from './Reporter/reporter.component';
import { EditorComponent } from './Editor/editor.component';
import {TabViewModule} from 'primeng/tabview';
import { DealsComponent } from './deals/deals.component';
import { ServicesDeal } from './services/services.deal';
import { HttpClientModule } from '@angular/common/http';
import { MatTableModule, MatPaginatorModule, MatSortModule, MatButtonModule, MatInputModule, MatDialogModule, MatFormFieldModule, MatIconModule, MatRadioButton } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommentComponent } from './comment/comment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './services/service.authguard';
import { AuthService } from './services/service.authenticationservice';
import { PasswordValidator } from './login/passwordvalidator.directive';
import { DealsFilterComponent } from './deals/deals.filtercomponent';


@NgModule({
  declarations: [
    AppComponent,MenuComponent,ReporterComponent,EditorComponent,DealsComponent, CommentComponent, LoginComponent, PasswordValidator, DealsFilterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MenubarModule,
    TabViewModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatInputModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule
       
  ],

  providers: [ ServicesMenu,ServicesDeal,AuthGuardService,AuthService],
  entryComponents: [CommentComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
