import { Component } from "@angular/core";


@Component({
templateUrl:'./reporter.component.html',
styleUrls:['./reporter.component.css']
})
export class ReporterComponent{

}