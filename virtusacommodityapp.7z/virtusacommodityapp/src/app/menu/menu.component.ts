import { ServicesMenu } from '../services/services.menu';
import { OnInit, Component } from '@angular/core';
import { AuthService } from '../services/service.authenticationservice';

@Component({
    selector: 'commodity-menu',
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.css']
  })
export class MenuComponent implements OnInit{

    private items:any;

    constructor(public nav: AuthService, private serviceObj:ServicesMenu){

    }

    ngOnInit(){
        this.items= this.serviceObj.getMenuItems();
    }
}