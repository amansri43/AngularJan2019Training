import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReporterComponent } from './Reporter/reporter.component';
import { EditorComponent } from './Editor/editor.component';
import { AuthGuardService } from './services/service.authguard';
import { CanActivate } from '@angular/router/src/utils/preactivation';
import { LoginComponent } from './login/login.component';

const routes: Routes = [{
  path:'RevenueReporting',
  component:ReporterComponent,
  outlet:'RROutlet',
  canActivate: [AuthGuardService]
},
{
  path:'RevenueEditor/:p1/:p2/:p3',
  component:EditorComponent,
  outlet:'REOutlet',
  
},
{
  path:'RevenueEditor',
  component:EditorComponent,
  outlet:'REOutlet',
  canActivate: [AuthGuardService]
},
{
  path:'',
  component:LoginComponent,
  outlet:'LoginOutlet'
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
