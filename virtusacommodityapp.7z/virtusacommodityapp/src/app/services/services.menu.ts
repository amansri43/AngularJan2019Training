import { Injectable } from '@angular/core';
import { data } from '../models/models.menudata';

@Injectable()
export class ServicesMenu{

getMenuItems():any{
    return data;
}
}