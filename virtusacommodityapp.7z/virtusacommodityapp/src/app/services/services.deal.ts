
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { deals } from '../data/data';


@Injectable()
export class ServicesDeal{

    constructor(private http:HttpClient){

    }

    getDeals(){

       // return this.http.get("https://www.quandl.com/api/v3/datasets/OPEC/ORB.json");
       return (deals);
    }
}