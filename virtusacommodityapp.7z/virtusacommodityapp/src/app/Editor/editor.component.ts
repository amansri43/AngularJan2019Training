import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormBuilder, Validators, FormGroup } from '@angular/forms';


@Component({
templateUrl:'./editor.component.html',
styleUrls:['./editor.component.css']
})
export class EditorComponent implements OnInit{
    public date:FormControl;
    public value:FormControl;
    public comment:FormControl;
    public dealForm:FormGroup;

    public rdate:string;
    public rvalue:number;
    public rcomment:string;


constructor(private route:ActivatedRoute, private formBuilder: FormBuilder){

    this.date= new FormControl('',[Validators.required]);
    this.value= new FormControl('',[Validators.required, Validators.min(10), Validators.max(500)]);
    this.comment= new FormControl('',[Validators.required, Validators.pattern('[A-Za-z0-9]{5,150}')]);

    this.dealForm=formBuilder.group(
        {
            date:this.date,
            value:this.value,
            comment:this.comment
        }
    )
}

ngOnInit(){

    this.route.params.subscribe(param=>{
        console.log(param);
        this.rdate=param.p1;
        this.rvalue= param.p2;
        this.rcomment=param.p3;
    })
    //console.log(this.route.snapshot.params);
}

save(){
    console.log();
}
}