import { PipeTransform, Pipe } from '@angular/core';

@Pipe({name:"DealFilter"})
export class DealsFilterComponent implements PipeTransform{

    transform(value:any, filterValue:number):any{
        console.log(value);
        console.log(filterValue);
        return value.filter(obj=>obj[1]>filterValue);
    }
}